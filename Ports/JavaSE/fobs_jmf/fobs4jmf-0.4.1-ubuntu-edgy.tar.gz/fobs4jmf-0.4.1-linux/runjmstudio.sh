#!/bin/bash


WORKINGDIR=${0%/*}

DYLD_LIBRARY_PATH=$WORKINGDIR
export DYLD_LIBRARY_PATH


JAVA_CMD="$JAVA_HOME/bin/java"
if [ -z "$JAVA_HOME" ]; then
    JAVA_CMD="java"
fi

CP_JAVA=$WORKINGDIR/jmf.jar:$WORKINGDIR/fobs4jmf.jar


echo $JAVA_CMD -classpath $CP_JAVA JMStudio
$JAVA_CMD -classpath $CP_JAVA JMStudio